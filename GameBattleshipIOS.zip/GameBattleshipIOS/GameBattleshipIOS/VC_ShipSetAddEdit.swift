//
//  VC_ShipSetAddEdit.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 15/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_ShipSetAddEdit: UIViewController {
    @IBOutlet weak var sliderSize: UISlider!
    @IBOutlet weak var sliderNumber: UISlider!
    @IBOutlet weak var imageSize: UIImageView!
    @IBOutlet weak var imageNumber: UIImageView!
    
    private var ship: (size: Int, number: Int)!
    var parentController: VC_ShipSet!
    var viewMode = ViewMode.undefined
    var indexShip: Int?
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        switch viewMode {
        case .add:
            //print(StaticVariable.Info + ": Add mode")
            ship = (size: 1, number: 1)
        case .edit:
            //print(StaticVariable.Info + ": Edit mode")
            ship = parentController.shipSet.getShip(atIndex: indexShip!)
        default:
            print(StaticVariable.Error + ": Bad view mode")
        }
        
        sliderSize.setValue(Float(ship.size), animated: true)
        sliderNumber.setValue(Float(ship.number), animated: true)
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func sliderSizeChange(_ sender: UISlider) {
        //print(sliderSize.value.rounded(.down))
    }
    
    @IBAction func sliderNumberChange(_ sender: UISlider) {
        //print(sliderNumber.value.rounded(.down))
    }
    
    @IBAction func buttonAcceptPress(_ sender: UIButton) {
        let size = Int(sliderSize.value.rounded(.down))
        let number = Int(sliderNumber.value.rounded(.down))
        
        let currentNumber = parentController.shipSet.getShip(ofSize: size)
        
        if currentNumber == nil {
            if viewMode == .add {
                parentController.shipSet.addShip(ofSize: size, number: number)
            } else if viewMode == .edit {
                parentController.shipSet.editShip(ofSize: ship.size,
                                                  number: ship.number,
                                                  toSize: size,
                                                  numberNew: number)
            }
            parentController.tableViewShipSet.reloadData()
            navigationController?.popViewController(animated: true)
        } else {
            // BEGIN action dialog
            let message = String.localizedStringWithFormat(AppStrings.questionReplaceShipDefinition,
                                                           "\(currentNumber!)")
            let alert = UIAlertController(title: AppStrings.question,
                                          message: message,
                                          preferredStyle: UIAlertController.Style.alert)
            
            // OK
            alert.addAction(UIAlertAction(title: AppStrings.accept,
                                          style: .destructive,
                                          handler: { (action: UIAlertAction!) in
                self.parentController.shipSet.addShip(ofSize: size, number: number)
                self.parentController.tableViewShipSet.reloadData()
                self.navigationController?.popViewController(animated: true)
            }))
            
            // Cancel
            alert.addAction(UIAlertAction(title: AppStrings.cancel,
                                          style: .cancel,
                                          handler: { (action: UIAlertAction!) in
                
            }))
            
            self.present(alert, animated: true, completion: nil)
            // END action dialog
        }
    }
    
    @IBAction func buttonCancelPress(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    
    // END My functions
}
