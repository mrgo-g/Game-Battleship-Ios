//
//  TVC_ShipSets.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 08/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class TVC_ShipSets: UITableViewController {
    @IBOutlet weak var barButtonMove: UIBarButtonItem!
    @IBOutlet weak var barButtonAdd: UIBarButtonItem!
    
    private var managerSettings = ManagerSettings.sharedInstance
    var viewMode = ViewMode.undefined
    var indexShipSet: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        switch viewMode {
        case .editable:
            barButtonMove.isEnabled = true
            barButtonAdd.isEnabled = true
        case .noneditable:
            barButtonMove.isEnabled = false
            barButtonAdd.isEnabled = false
        default:
            print(StaticVariable.Warning + ": Bad view mode")
        }
        
        tableView.isEditing = false
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == StaticVariable.SegueFromShipSetsToShipSet) {
            if let destVC = segue.destination as? VC_ShipSet {
                if let sender = sender {
                    if sender is TVC_ShipSets {
                        destVC.viewMode = .edit
                        destVC.indexShipSet = indexShipSet
                        destVC.parentController = self
                    }
                    else if sender is UIBarButtonItem {
                        destVC.viewMode = .add
                        destVC.indexShipSet = nil
                        destVC.parentController = self
                    }
                }
            }
        }
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return managerSettings.shipSets.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: StaticVariable.ListCellShipSet)
        
        if cell == nil {
            cell = UITableViewCell(style: .subtitle,
                                   reuseIdentifier: StaticVariable.ListCellShipSet)
        }
        
        cell?.textLabel?.text = managerSettings.shipSets[indexPath.row].name
        cell?.detailTextLabel?.text = managerSettings.shipSets[indexPath.row].description
        
        if indexShipSet != nil && indexShipSet == indexPath.row {
            tableView.selectRow(at: indexPath, animated: false, scrollPosition: .none)
        }
        
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if viewMode == .noneditable {
            if indexShipSet == indexPath.row {
                indexShipSet = nil
                if let cell = tableView.cellForRow(at: indexPath) as? UITableViewCell {
                    cell.isSelected = false
                }
            } else {
                indexShipSet = indexPath.row
            }
        } else if viewMode == .editable {
            indexShipSet = indexPath.row
            self.performSegue(withIdentifier: StaticVariable.SegueFromShipSetsToShipSet, sender: self)
        }
    }
    
    override func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        guard viewMode == .editable else {return nil}
        
        let actionDelete = UIContextualAction(style: .destructive,
                                              title:  AppStrings.delete,
                                              handler:
            {(action:UIContextualAction, view:UIView, completionHandler:(Bool) -> Void) in
                let uuid =  self.managerSettings.shipSets[indexPath.row].uuid
                if let indexGameDefinition = self.managerSettings.isThisShipSetUsed(uuid: uuid) {
                    let gameDefinitionName = self.managerSettings.gameDefinitions[indexGameDefinition].name
                    let message = String.localizedStringWithFormat(AppStrings.informationShipSetIsUsed,
                                                                   "\(gameDefinitionName ?? AppStrings.unknown)")
                    let alert = UIAlertController(title: AppStrings.information,
                                                  message: message,
                                                  preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: AppStrings.ok,
                                                  style: .default,
                                                  handler: { (_) in
                    }))
                    
                    self.present(alert, animated: true, completion: nil)
                } else {
                    self.managerSettings.shipSets.remove(at: indexPath.row)
                    tableView.reloadData()
                }
                completionHandler(true)
        }
        )
        actionDelete.backgroundColor = .red
        
        let configuration = UISwipeActionsConfiguration(actions: [actionDelete])
        configuration.performsFirstActionWithFullSwipe = false
        return configuration
    }
    
    override func tableView(_ tableView: UITableView,
                            editingStyleForRowAt indexPath: IndexPath
    ) -> UITableViewCell.EditingStyle {
        return .none
    }
    
    override func tableView(_ tableView: UITableView,
                            shouldIndentWhileEditingRowAt indexPath: IndexPath
    ) -> Bool {
        return false
    }
    
    override func tableView(_ tableView: UITableView,
                            canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView,
                            moveRowAt sourceIndexPath: IndexPath,
                            to destinationIndexPath: IndexPath) {
        
        let set = self.managerSettings.shipSets.remove(at: sourceIndexPath.row)
        self.managerSettings.shipSets.insert(set, at: destinationIndexPath.row)
        
        tableView.reloadData()
    }
   
    @IBAction func barButtonReorderPress(_ sender: UIBarButtonItem) {
        self.tableView.isEditing = !self.tableView.isEditing
    }
   
}
