//
//  VC_ShipSet.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 15/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_ShipSet: UIViewController {
    private var managerSettings = ManagerSettings.sharedInstance
    
    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var textFieldDescription: UITextField!
    @IBOutlet weak var tableViewShipSet: UITableView!
    
    private var indexShip: Int?
    var shipSet: ShipSet!
    var viewMode = ViewMode.undefined
    var parentController: TVC_ShipSets!
    var indexShipSet: Int?
    
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()

        switch viewMode {
        case .add:
            //print(StaticVariable.Info + ": Add mode")
            shipSet = ShipSet(name: nil, description: nil, uuid: UUID())
        case .edit:
            //print(StaticVariable.Info + ": Edit mode")
            textFieldName.text = managerSettings.shipSets[indexShipSet!].name
            textFieldDescription.text = managerSettings.shipSets[indexShipSet!].description
            
            shipSet = managerSettings.shipSets[indexShipSet!].copy() as? ShipSet
        default:
            print(StaticVariable.Error + ": Bad view mode")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == StaticVariable.SegueFromShipSetToShipSetAddEdit) {
            if let destVC = segue.destination as? VC_ShipSetAddEdit {
                if let sender = sender {
                    if sender is VC_ShipSet {
                        destVC.viewMode = .edit
                        destVC.indexShip = indexShip!
                        destVC.parentController = self
                    }
                    else if sender is UIBarButtonItem {
                        destVC.viewMode = .add
                        destVC.indexShip = nil
                        destVC.parentController = self
                    }
                }
            }
        }
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func barButtonSavePress(_ sender: UIBarButtonItem) {
        if let name = textFieldName.text,
            !name.isEmpty &&
            shipSet.getShipsNumber()  > 0
        {
            shipSet.name = textFieldName.text
            shipSet.description = textFieldDescription.text
            
            if indexShipSet != nil {
                managerSettings.shipSets[indexShipSet!] = shipSet
            } else {
                managerSettings.shipSets.append(shipSet)
            }
            
            managerSettings.saveShipSets()
            
            self.navigationController?.popViewController(animated: true)
            parentController.tableView.reloadData()
        } else {
            // BEGIN action dialog
            let alert = UIAlertController(title: AppStrings.information,
                                          message: AppStrings.missingShipSetInformations,
                                          preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: AppStrings.ok,
                                          style: .default,
                                          handler: { (_) in
            }))
            
            self.present(alert, animated: true, completion: nil)
            // END action dialog
        }
    }
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    public func checkIfEdited() -> Bool {
        if shipSet.name != textFieldName.text {
            return true
        }
        if shipSet.description != textFieldDescription.text {
            return true
        }
        if let indexShipSet = indexShipSet {
            if shipSet.getShipsNumber() != managerSettings.shipSets[indexShipSet].getShipsNumber() {
                return true
            }
            
            let currentSet = shipSet.getShipsAllSorted()
            let previousSet = managerSettings.shipSets[indexShipSet].getShipsAllSorted()
            
            let limit = currentSet.count
            for index in 0..<limit {
                if currentSet[index].number != previousSet[index].number ||
                    currentSet[index].size != currentSet[index].size {
                    return false
                }
            }
        }
        return false
    }
    // END My functions
}

// MARK: - UITableViewDataSource extension
extension VC_ShipSet: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shipSet.getShipsNumber()
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: StaticVariable.ListCellShip)
        
        if cell == nil {
            cell = UITableViewCell(style: .subtitle,
                                   reuseIdentifier: StaticVariable.ListCellShip)
        }
        
        let ship = shipSet.getShip(atIndex: indexPath.row)

        cell?.textLabel?.text = "ship size: \(ship.size)"
        cell?.detailTextLabel?.text = "number: \(ship.number)"

        return cell!
    }
    
    func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let actionDelete = UIContextualAction(style: .normal,
                                              title:  AppStrings.delete,
                                              handler:
            {(action:UIContextualAction, view:UIView, completionHandler:(Bool) -> Void) in
                self.shipSet.removeShip(atIndex: indexPath.row)
                tableView.reloadData()
                completionHandler(true)
        }
        )
        actionDelete.backgroundColor = .red
        
        let configuration = UISwipeActionsConfiguration(actions: [actionDelete])
        configuration.performsFirstActionWithFullSwipe = false
        return configuration
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        indexShip = indexPath.row
        self.performSegue(withIdentifier: StaticVariable.SegueFromShipSetToShipSetAddEdit, sender: self)
    }
}

// MARK: - UITableViewDelegate extension
extension VC_ShipSet: UITableViewDelegate {
    
}
