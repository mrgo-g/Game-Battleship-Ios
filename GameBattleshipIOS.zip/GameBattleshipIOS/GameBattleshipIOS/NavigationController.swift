//
//  NavigationController.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 18/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

// http://www.programmersought.com/article/1529883806/
// https://stackoverflow.com/questions/27713747/execute-action-when-back-bar-button-of-uinavigationcontroller-is-pressed
// https://stackoverflow.com/questions/8228411/detecting-when-the-back-button-is-pressed-on-a-navbar/14155394

import UIKit

protocol NavigationControllerBackButtonDelegate {
    func shouldPopOnBackButtonPress() -> Bool
}

class NavigationController: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
        print("NavigationController")
    }
}

extension UINavigationController: UINavigationBarDelegate {
    public func navigationBar(_ navigationBar: UINavigationBar,
                               shouldPop item: UINavigationItem) -> Bool {
        print("UINavigationBarDelegate?")
        return false
          //return self.topViewController?.navigationShouldPopOnBackButton() ?? true
    }
    /*
     func navigationBar(_ navigationBar: UINavigationBar, shouldPop item: UINavigationItem) -> Bool {
         var shouldPop = true
         
                // modified (mark 1)
         let viewControllersCount = self.viewControllers.count
         let navigationItemsCount = navigationBar.items?.count
         
         if(viewControllersCount < navigationItemsCount!){
             return shouldPop
         }
         if let topViewController: UIViewController = self.topViewController {
             if(topViewController is NavigationControllerBackButtonDelegate){
                 let delegate = topViewController as! NavigationControllerBackButtonDelegate
                 shouldPop = delegate.shouldPopOnBackButtonPress()
             }
         }
         if(shouldPop == false){
             isNavigationBarHidden = true
             isNavigationBarHidden = false
         }else{
             if(viewControllerCount >= navigationItemCount!){
                 DispatchQueue.main.async { () -> Void in
                     self.popViewController(animated: true)
                 }
             }
         }
         return shouldPop
     }
     
     */
    /*
     // 2, MyViewController.swift, complete the custom pop rules. Implement NavigationControllerBackButtonDelegate
     class MyViewController: UIViewController, NavigationControllerBackButtonDelegate {
       // MARK: NavigationController delegate
         func shouldPopOnBackButtonPress() -> Bool {
             var shouldPop = true
             if(self.customiseBack == true){
                 // do something private
                 shouldPop = false
             }
             return shouldPop
         }
     }
     */
}
