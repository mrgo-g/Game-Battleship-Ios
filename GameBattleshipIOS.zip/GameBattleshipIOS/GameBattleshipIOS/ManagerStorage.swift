//
//  ManagerStorage.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 07/05/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class ManagerStorage {
    static let sharedInstance = ManagerStorage()
    
    private var storageFile = StorageFile.sharedInstance
    private var storageUserDefaults = StorageUserDefaults.sharedInstance
    
    func loadGameDefinitions() -> [GameDefinition]? {
        return storageFile.loadGameDefinitions()
    }
    
    func loadBoard(of: StorageFile.DataType) -> Board? {
        return storageFile.loadBoard(of: of)
    }
    
    func loadSettings() -> ManagerSettings.Settings? {
        return storageFile.loadSettings()
    }
    
    func loadShipSets() -> [ShipSet]? {
        return storageFile.loadShipSets()
    }
    
    func loadStateDataAsInt(forKey: String) -> Int? {
        storageUserDefaults.loadInt(forKey: forKey)
    }
    
    func loadStateDataAsString(forKey: String) -> String? {
        storageUserDefaults.loadString(forKey: forKey)
    }
    
    func save(board: Board, of: StorageFile.DataType) {
        storageFile.save(board: board, of: of)
    }
        
    func save(settings: ManagerSettings.Settings) {
        storageFile.save(settings: settings)
    }
    
    func save(shipSets: [ShipSet]) {
        storageFile.save(shipSets: shipSets)
    }
    
    func save(gameDefinitions: [GameDefinition]) {
        storageFile.save(gameDefinitions: gameDefinitions)
    }
    
    func saveStateData(value: Int, forKey: String) {
        storageUserDefaults.save(value: value, forKey: forKey)
    }
    
    func saveStateData(value: String, forKey: String) {
        storageUserDefaults.save(value: value, forKey: forKey)
    }
}
