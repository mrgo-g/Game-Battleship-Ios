//
//  VC_GameParameters.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 02/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_GameParameters: UIViewController {
    @IBOutlet weak var labelShipSetName: UILabel!
    @IBOutlet weak var buttonPlay: UIButton!
    @IBOutlet weak var buttonContinueLastGame: UIButton!
    @IBOutlet weak var textFieldPlayerName: UITextField!
    @IBOutlet weak var textFieldRows: UITextField!
    @IBOutlet weak var textFieldColumns: UITextField!
    
    private var managerGame = ManagerGame.sharedInstance
    private var managerSettings = ManagerSettings.sharedInstance
    private var managerStorage = ManagerStorage.sharedInstance
    
    //private var shipSet: ShipSet?
    private var indexShipSet: Int?
    private var indexGameDefinition: Int?
    
    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldRows.delegate = self
        textFieldColumns.delegate = self
        refreshView()
        checkIfThereIsAGameToRestore()
    }
    
    override func canPerformUnwindSegueAction(_ action: Selector,
      from fromViewController: UIViewController,
      sender: Any?) -> Bool {
        if let fromVC = fromViewController as? TVC_GameDefinitions {
            if fromVC.viewMode == .noneditable {
                return true
            }
        } else if let fromVC = fromViewController as? TVC_ShipSets {
            if fromVC.viewMode == .noneditable {
                return true
            }
        } else if let _ = fromViewController as? VC_Play_Opponent_Ships {
            return true
        }
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == StaticVariable.SegueFromGameParametersToShipSets) {
            // targetController TVC_ShipSets is "hidden" behind destVC UINavigationController
            if let destVC = segue.destination as? UINavigationController,
                let targetController = destVC.topViewController as? TVC_ShipSets {
                targetController.viewMode = .noneditable
                targetController.indexShipSet = indexShipSet
            }
        } else if (segue.identifier == StaticVariable.SegueFromGameParametersToGameDefinitions) {
            if let destVC = segue.destination as? UINavigationController,
                let targetController = destVC.topViewController as? TVC_GameDefinitions {
                targetController.viewMode = .noneditable
                targetController.indexGameDefinition = indexGameDefinition
            }
        } else if (segue.identifier == StaticVariable.SegueFromGameParametersToDeployShips) {
            if let _ = segue.destination as? VC_DeployShips {
                if let indexGameDefinition = indexGameDefinition {
                    let rows = managerSettings.gameDefinitions[indexGameDefinition].rows
                    let columns = managerSettings.gameDefinitions[indexGameDefinition].columns
                    let shipSetUUID = managerSettings.gameDefinitions[indexGameDefinition].shipSetUUID!
                    let indexShipSet = managerSettings.getShipSetIndex(forShipSetUUID: shipSetUUID)
                    let shipsSize = managerSettings.shipSets[indexShipSet!].getShipsAllSortedOneByOne()
                    managerGame.createGame(rows: rows, cols: columns, shipsSize: shipsSize)
                } else {
                    let rows = Int(textFieldRows.text!)!
                    let columns = Int(textFieldColumns.text!)!
                    let shipsSize = managerSettings.shipSets[indexShipSet!].getShipsAllSortedOneByOne()
                    managerGame.createGame(rows: rows, cols: columns, shipsSize: shipsSize)
                }
            }
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String?, sender: Any?) -> Bool {
        if let identifier = identifier {
            if identifier == StaticVariable.SegueFromGameParametersToDeployShips {
                if allDataComplete() {
                    return true
                } else {
                    // BEGIN action dialog
                    let alert = UIAlertController(title: AppStrings.information,
                                                  message: AppStrings.missingGameInformations,
                                                  preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: AppStrings.ok,
                                                  style: .default,
                                                  handler: { (_) in
                    }))
                    
                    self.present(alert, animated: true, completion: nil)
                    // END action dialog
                    return false
                }
            } else if identifier == StaticVariable.SegueFromGameParametersToShipSets {
                return  true
            }
        }
        return false
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func unwindFromShipSets(segue: UIStoryboardSegue){
        if let fromVC = segue.source as? TVC_ShipSets {
            indexShipSet = fromVC.indexShipSet
            indexGameDefinition = nil
            refreshView()
        }
    }
    
    @IBAction func unwindFromGameDefinitions(segue: UIStoryboardSegue){
        if let fromVC = segue.source as? TVC_GameDefinitions {
            indexGameDefinition = fromVC.indexGameDefinition
            indexShipSet = nil
            refreshView()
        }
    }
    
    @IBAction func unwindFromPlay(segue: UIStoryboardSegue){
        buttonContinueLastGame.isEnabled = false
        managerStorage.saveStateData(value: VC_Play.PlayLoopStage.end.rawValue,
                                     forKey: StorageUserDefaults.Key.playLoopStage)
    }
    
    @IBAction func buttonSelectPredefinedGamePress(_ sender: UIButton) {
        self.performSegue(withIdentifier: StaticVariable.SegueFromGameParametersToGameDefinitions,
                          sender: self)
    }
    
    @IBAction func buttonContinueLastGamePress(_ sender: UIButton) {
        var success = true
        
        let boardOpponent = managerStorage.loadBoard(of: StorageFile.DataType.boardOpponent)
        if boardOpponent == nil {
            success = false
        }
    
        let boardPlayer = managerStorage.loadBoard(of: StorageFile.DataType.boardPlayer)
        if boardPlayer == nil {
            success = false
        }
        
        if let playLoopStage = managerStorage.loadStateDataAsInt(forKey: StorageUserDefaults.Key.playLoopStage) {
            managerGame.playLoopStage = VC_Play.getPlayLoopStage(forInt: playLoopStage)
        } else {
            success = false
        }
        
        if let visibleView = managerStorage.loadStateDataAsInt(forKey: StorageUserDefaults.Key.visibleView) {
            if visibleView > 0 {
                managerGame.visibleView = visibleView
            } else {
                success = false
            }
        } else {
            success = false
        }
        
        if let message = managerStorage.loadStateDataAsString(forKey: StorageUserDefaults.Key.messageToDisplayInNextView) {
            managerGame.messageToDisplayInNextView = message
        } else {
            managerGame.messageToDisplayInNextView = ""
        }

        if success == false {
            // BEGIN action dialog
            let message = String.localizedStringWithFormat(AppStrings.shotCoordinatesOutOfRange,
                                                           AppStrings.row)
            
            let alert = UIAlertController(title: AppStrings.information,
                                          message: message,
                                          preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: AppStrings.ok,
                                          style: .default,
                                          handler: { (_) in
            }))
            
            self.present(alert, animated: true, completion: nil)
            // END action dialog
        } else {
            managerGame.restoreGameEngine(boardPlayer: boardPlayer!, boardOpponent: boardOpponent!)
            let vc = (self.storyboard?.instantiateViewController(withIdentifier: StaticVariable.ID_VC_Play) as! VC_Play)
            vc.modalPresentationStyle = .overFullScreen
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    @IBAction func buttonPlayPress(_ sender: UIButton) {
    }
    // END Actions

    // MARK: - My functions
    // BEGIN My functions
    private func allDataComplete() -> Bool {
        // Check if game definition is selected
        // TODO:
        // Game definition is not yet implemented, so this should be
        // implemented later
        
        // If game definiton is not selected, check if rows, columns
        // and ship set is selected.
        if let rows = textFieldRows.text,
            let columns = textFieldColumns.text,
            //let name = textFieldPlayerName.text,
            let _ = indexShipSet,
            //!name.isEmpty &&
            !rows.isEmpty &&
            !columns.isEmpty &&
            Int(rows)! > 0 &&
            Int(columns)! > 0
        {
            return true
        }
        else if let _ = indexGameDefinition {
            return true
        }
        return false
    }
    
    private func checkIfThereIsAGameToRestore() {
        let playLoopStage = managerStorage.loadStateDataAsInt(forKey: StorageUserDefaults.Key.playLoopStage)
        if let playLoopStage = playLoopStage {
            if playLoopStage == VC_Play.PlayLoopStage.end.rawValue {
                buttonContinueLastGame.isEnabled = false
            } else {
                buttonContinueLastGame.isEnabled = true
            }
        } else {
            buttonContinueLastGame.isEnabled = false
        }
    }
    
    private func refreshView() {
        if indexGameDefinition != nil {
            let rows = managerSettings.gameDefinitions[indexGameDefinition!].rows
            let columns = managerSettings.gameDefinitions[indexGameDefinition!].columns
            textFieldRows.text = "\(rows)"
            textFieldColumns.text = "\(columns)"
            let shipSetUUID = managerSettings.gameDefinitions[indexGameDefinition!].shipSetUUID!
            let indexShipSet = managerSettings.getShipSetIndex(forShipSetUUID: shipSetUUID)
            labelShipSetName.text = managerSettings.shipSets[indexShipSet!].name
        } else if indexShipSet != nil {
            labelShipSetName.text = managerSettings.shipSets[indexShipSet!].name
        } else {
            labelShipSetName.text = nil
        }
    }
    // END My functions
}

extension VC_GameParameters: UITextFieldDelegate {
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool
    {
        if string.count == 0 {
            return true
        }
        
        if string.rangeOfCharacter(from: NSCharacterSet.decimalDigits) != nil {
            return true
        } else {
            return false
        }
    }
}
