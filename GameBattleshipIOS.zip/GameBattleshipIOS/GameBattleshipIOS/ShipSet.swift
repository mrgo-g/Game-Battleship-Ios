//
//  ShipSet.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 08/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation
import UIKit

class ShipSet {
    private var ships = [Int:Int]()
    // Sorted version of ships used to fasten access for table view
    private var shipsSorted = [(size: Int, number: Int)]()
    let uuid: UUID
    var name: String?
    var description: String?

    
    init(name: String?, description:String?, uuid: UUID) {
        self.name = name
        self.description = description
        self.uuid = uuid
    }
    
    func addShip(ofSize: Int, number: Int) {
        ships[ofSize] = number
        sortShips()
    }
    
    func addShips(ships: [Int: Int]) {
        self.ships.merge(ships) { (_, new) in new }
        sortShips()
    }
    
    func addShips(ships: [(size: Int, number: Int)]) {
        for ship in ships {
            self.ships[ship.size] = ship.number
        }
        sortShips()
    }
    
    func editShip(ofSize: Int, number: Int, toSize: Int, numberNew: Int) {
        if ofSize == toSize {
            ships[ofSize] = numberNew
        } else {
            ships.removeValue(forKey: ofSize)
            addShip(ofSize: toSize, number: numberNew)
        }
    }
    
    func getShip(atIndex: Int) -> (size: Int, number: Int) {
        return shipsSorted[atIndex]
    }
    
    func getShip(ofSize: Int) -> Int? {
        return ships[ofSize]
    }
    
    func getShipAll() -> [Int:Int] {
        return ships
    }
    
    func getShipsNumber() -> Int {
        return ships.count
    }
    
    // Return type is of [Dictionary<Int, Int>.Element]
    // a.k.a. Array<(key: Int, value: Int)>
    func getShipsAllSorted() -> Array<(size: Int, number: Int)> {
        sortShips()
        return shipsSorted
    }
    
    func getShipsAllSortedOneByOne() -> [Int] {
        let shipsAllSorted = getShipsAllSorted()
        var oneByOne = [Int]()
        
        for ship in shipsAllSorted {
            for _ in 0..<ship.number {
                oneByOne.append(ship.size)
            }
        }
        
        return oneByOne
    }
    
    func removeShip(ofSize: Int) {
        ships.removeValue(forKey: ofSize)
        sortShips()
    }
    
    func removeShip(atIndex: Int) {
        guard atIndex >= 0 else {return}
        
        let ship = shipsSorted[atIndex]
        removeShip(ofSize: ship.size)
    }
    

    private func sortShips() {
        if VC_Settings.logic == true
        {let shipsSortedTmp = ships.sorted( by: { $0.0 > $1.0 })
            shipsSorted.removeAll()
            for item in shipsSortedTmp {
                shipsSorted.append((size: item.key, number: item.value))
            }
        }
        else{let shipsSortedTmp = ships.sorted( by: { $1.0 > $0.0 })
            shipsSorted.removeAll()
            for item in shipsSortedTmp {
                shipsSorted.append((size: item.key, number: item.value))
            }
        }
        
    }
    
    private func REVsortShips() {
         let shipsSortedTmp = ships.sorted( by: { $1.0 > $0.0 })
         shipsSorted.removeAll()
         
         for item in shipsSortedTmp {
             shipsSorted.append((size: item.key, number: item.value))
         }
     }
}

extension ShipSet: NSCopying {
    func copy(with zone: NSZone? = nil) -> Any {
        let copy = ShipSet(name: name, description: description, uuid: uuid)
        copy.addShips(ships: ships)
        return copy
    }
}
