//
//  Constants.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 08/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation
import UIKit

enum ViewMode {
    case undefined, editable, noneditable, add, edit
}

struct GameColors {
    static let black = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
    static let blue = UIColor.blue
    static let blueDark = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1) //#colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)
    static let blueLight = #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1)
    static let gray = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
    static let grayLight = #colorLiteral(red: 0.9358132482, green: 0.9358132482, blue: 0.9358132482, alpha: 1)
    static let green = UIColor.green
    static let orange = UIColor.orange
    static let red = UIColor.red
    static let white = UIColor.white
    static let yellow = UIColor.yellow
}

struct StaticVariable {
    // Or you can use note books 📕 📙 📗 📘 📓 📔
    static let Info = "🟢"
    static let Warning = "⚠️"
    static let Error = "🛑"
    
    static let ID_VC_Play = "ID_VC_Play"
    
    static let ListCellShipSet = "ListCellShipSet"
    static let ListCellGameDefinition = "ListCellGameDefinition"
    static let ListCellShip = "ListCellShip"
    
    static let SegueFromGameParametersToDeployShips = "SegueFromGameParametersToDeployShips"
    static let SegueFromGameParametersToGameDefinitions = "SegueFromGameParametersToGameDefinitions"
    static let SegueFromGameParametersToPlay = "SegueFromGameParametersToPlay"
    static let SegueFromGameParametersToShipSets = "SegueFromGameParametersToShipSets"
    static let SegueFromSettingsToShipSets = "SegueFromSettingsToShipSets"
    static let SegueFromSettingsToGameDefinitions = "SegueFromSettingsToGameDefinitions"
    static let SegueFromShipSetsToShipSet = "SegueFromShipSetsToShipSet"
    static let SegueFromShipSetToShipSetAddEdit = "SegueFromShipSetToShipSetAddEdit"
    static let SegueFromGameDefinitionsToGameDefinition = "SegueFromGameDefinitionsToGameDefinition"
    static let SegueFromGameDefinitionToShipSets = "SegueFromGameDefinitionToShipSets"
}

struct AppStrings{
    //static let back = NSLocalizedString("Back", comment: "")
    static let accept = NSLocalizedString("Accept", comment: "")
    static let cancel = NSLocalizedString("Cancel", comment: "")
    static let column = NSLocalizedString("column", comment: "")
    static let delete = NSLocalizedString("Delete", comment: "")
    static let empty = NSLocalizedString("", comment: "")
    static let information = NSLocalizedString("Information", comment: "")
    static let ok = NSLocalizedString("OK", comment: "")
    static let opponent = NSLocalizedString("Opponent", comment: "")
    static let player = NSLocalizedString("Player", comment: "")
    static let question = NSLocalizedString("Question", comment: "")
    static let row = NSLocalizedString("row", comment: "")
    static let shoot = NSLocalizedString("Shoot", comment: "")
    static let shootResultDestroyed = NSLocalizedString("Destroyed", comment: "")
    static let shootResultHit = NSLocalizedString("Hit", comment: "")
    static let shootResultMissed = NSLocalizedString("Missed", comment: "")
    static let unknown = NSLocalizedString("Unknown", comment: "")
    
    static let cantShootAtThisField = NSLocalizedString("You can't shoot at this field", comment: "")
    static let failLoadPreviousGame = NSLocalizedString("Failed to load saved game", comment: "")
    static let incorrectShotCoordinates = NSLocalizedString("Incorrect shot coordinates", comment: "")
    static let informationShipSetIsUsed = NSLocalizedString("This ship set can't be deleted because is used by '%@' game definition", comment: "")
    static let missingGameDefinitionInformations = NSLocalizedString("Some informations needed to create a game definition are missing. Please check if you set name, number of rows and columns and ship set. Description is optional.", comment: "")
    static let missingGameInformations = NSLocalizedString("Some informations needed to set up game are missing. Please check if you set user name, number of rows and columns and ship set.", comment: "")
    static let missingShipSetInformations = NSLocalizedString("Some informations needed to create a ship set are missing. Please check if you set name and specify at least one ship type. Description is optional.", comment: "")
    static let notYetImplemented = NSLocalizedString("Not yet implemented", comment: "")
    static let reportAfterHit = NSLocalizedString("%@ of %@ sections remain", comment: "")
    static let questionReplaceShipDefinition = NSLocalizedString("Ship of this size is already defined (curent number is %@). Do you want to replace it's definition?", comment: "")
    static let shotCoordinatesOutOfRange = NSLocalizedString("Shot coordinates for %@ out of range", comment: "")
    static let theWinnerIs = NSLocalizedString("Game over!\n%@ is the winner", comment: "")
    static let unsuccessfulShipDeployment = NSLocalizedString("Unsuccessful ship deployment. Check game parameters and try again", comment: "")
    
}
