//
//  VC_Play.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 21/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import UIKit

class VC_Play: UIViewController {
    @IBOutlet weak var segmentedControlWhosShips: UISegmentedControl!
    @IBOutlet weak var containerView_A: UIView!
    @IBOutlet weak var containerView_B: UIView!
    
    private var managerGame = ManagerGame.sharedInstance
    private var managerSettings = ManagerSettings.sharedInstance
    
    private var containerViewWithOpponentShips: UIView!
    private var containerViewWithPlayerShips: UIView!
    private var vcPlayOpponentShips: VC_Play_Opponent_Ships?
    private var vcPlayPlayerShips: VC_Play_Player_Ships?
    
    
    
    enum PlayLoopStage: Int {
        case undefined=0, playerShoot=1, playerShotResults=2, opponentShotResult=3, end=4
    }
    
    class func getPlayLoopStage(forInt: Int) -> PlayLoopStage {
        if forInt == 1 {
            return .playerShoot
        } else if forInt == 2 {
            return .opponentShotResult
        } else if forInt == 3 {
            return .opponentShotResult
        } else if forInt == 4 {
            return .end
        }
        return .undefined
    }
    
    struct VisibleView {
        static let playerShips = 1
        static let opponentShips = 2
    }

    // MARK: - Overriden functions
    // BEGIN Overriden functions
    override func viewDidLoad() {
        super.viewDidLoad()
        vcPlayPlayerShips?.vcPlay = self
        vcPlayOpponentShips?.vcPlay = self
        containerViewWithPlayerShips = containerView_B
        containerViewWithOpponentShips = containerView_A
        displayView()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? VC_Play_Player_Ships {
            vcPlayPlayerShips = vc
        }
        else if let vc = segue.destination as? VC_Play_Opponent_Ships {
            vcPlayOpponentShips = vc
        }
    }
    // END Overriden functions
    
    // MARK: - Actions
    // BEGIN Actions
    @IBAction func segmentedControlValueChanged(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex
        {
        case VisibleView.playerShips:
            managerGame.visibleView = VisibleView.playerShips
        case VisibleView.opponentShips:
            managerGame.visibleView = VisibleView.opponentShips
        default:
            break;
        }
        displayView(updateMessage: false)
    }
    // END Actions
    
    // MARK: - My functions
    // BEGIN My functions
    private func displayView(updateMessage: Bool = true) {
        if managerGame.playLoopStage == .playerShoot {
            vcPlayPlayerShips?.buttonOK.isEnabled = false
            vcPlayOpponentShips?.buttonShoot.isEnabled = true
            
            if managerGame.visibleView == VisibleView.playerShips {
                
            } else if managerGame.visibleView == VisibleView.opponentShips {
                
            }
        } else if managerGame.playLoopStage == .playerShotResults {
            vcPlayOpponentShips?.buttonShoot.setTitle(AppStrings.ok, for: .normal)
            
            if managerGame.visibleView == VisibleView.playerShips {
                
            } else if managerGame.visibleView == VisibleView.opponentShips {
                
            }
        } else if managerGame.playLoopStage == .opponentShotResult {
            vcPlayPlayerShips?.buttonOK.isEnabled = true
            vcPlayOpponentShips?.textFieldRow.text = "1"
            vcPlayOpponentShips?.textFieldColumn.text = "1"
            vcPlayOpponentShips?.actionAfterRowOrColumnChanged(updateSlider: true)
            vcPlayOpponentShips?.buttonShoot.isEnabled = false
            vcPlayOpponentShips?.buttonShoot.setTitle(AppStrings.shoot, for: .normal)
            
            if managerGame.visibleView == VisibleView.playerShips {
                
            } else if managerGame.visibleView == VisibleView.opponentShips {
                
            }
        } else if managerGame.playLoopStage == .end {
            vcPlayPlayerShips?.buttonOK.isEnabled = false
            vcPlayOpponentShips?.textFieldRow.text = ""
            vcPlayOpponentShips?.textFieldColumn.text = ""
            vcPlayOpponentShips?.buttonShoot.isEnabled = false
        }
        
        if managerGame.visibleView == VisibleView.playerShips {
            containerViewWithPlayerShips.isHidden = false
            containerViewWithOpponentShips.isHidden = true
            if segmentedControlWhosShips.selectedSegmentIndex != VisibleView.playerShips {
                segmentedControlWhosShips.selectedSegmentIndex = VisibleView.playerShips
            }
            managerGame.refreshViewGameBoard(whoseBoard: .player)
            if updateMessage {
                vcPlayPlayerShips?.updateMessage()
            }
        } else if managerGame.visibleView == VisibleView.opponentShips {
            containerViewWithPlayerShips.isHidden = true
            containerViewWithOpponentShips.isHidden = false
            if segmentedControlWhosShips.selectedSegmentIndex != VisibleView.opponentShips {
                segmentedControlWhosShips.selectedSegmentIndex = VisibleView.opponentShips
            }
            managerGame.refreshViewGameBoard(whoseBoard: .opponent)
            if updateMessage {
                vcPlayOpponentShips?.updateMessage()
            }
        }
    }
    
    func nextStage() {
        if managerGame.playLoopStage == .playerShoot {
            managerGame.playLoopStage = .playerShotResults
            managerGame.visibleView = VisibleView.opponentShips
        } else if managerGame.playLoopStage == .playerShotResults {
            managerGame.playLoopStage = .opponentShotResult
            managerGame.visibleView = VisibleView.playerShips
        } else if managerGame.playLoopStage == .opponentShotResult {
            managerGame.playLoopStage = .playerShoot
            managerGame.visibleView = VisibleView.opponentShips
        }
        
        displayView()
        
        if let who = managerGame.engine.checkWhoWins() {
            var whoString = AppStrings.player
            if who == .opponent {
                whoString = AppStrings.opponent
            }
            
            // BEGIN action dialog
            let message = String.localizedStringWithFormat(AppStrings.theWinnerIs,
                                                           whoString)
            
            let alert = UIAlertController(title: AppStrings.information,
                                          message: message,
                                          preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: AppStrings.ok,
                                          style: .default,
                                          handler: { (_) in
            }))
            
            self.present(alert, animated: true, completion: nil)
            // END action dialog
            
            managerGame.playLoopStage = .end
        }
    }
    // END My functions
}
