//
//  ManagerSettings.swift
//  GameBattleshipIOS
//
//  Created by Piotr Fulmański on 08/04/2020.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class ManagerSettings {
    static let sharedInstance = ManagerSettings()
    private var managerStorege = ManagerStorage.sharedInstance
    
    var shipSets = [ShipSet]()
    var gameDefinitions = [GameDefinition]()
    
    var settings: Settings!
    
    class Settings: Codable {
        private var informationHit: Int?
        
        init() {
            setNilValues()
        }
        
        func getInformationHit() -> InformationHit {
            switch informationHit {
            case 1:
                return InformationHit.full
            case 2:
                return InformationHit.hitOrMiss
            default:
                return InformationHit.unknown
            }
        }
        
        func setInformationHit(value: InformationHit) {
            informationHit = value.rawValue
        }
        
        func setNilValues() {
            informationHit = InformationHit.full.rawValue
        }
    }
    
    enum InformationHit: Int {
        case unknown=0, full=1, hitOrMiss=2
    }
    
    init() {
        loadShipSets()
        loadGameDefinitions()
        loadSettings()
        
        /*
        var shipSet = ShipSet(name: "Classic set",
                              description: "1 x 4, 2 x 3, 3 x 2, 4 x 1",
                              uuid: UUID())
        shipSet.addShips(ships: [4: 1, 3: 2, 2: 3, 1: 4])
        shipSets.append(shipSet)
        
        var gameDefinition = GameDefinition(name: "Classic game",
                                            description: "10 x 10 with classic set of ships",
                                            rows: 10,
                                            columns: 10,
                                            shipSetUUID: shipSet.uuid)
        gameDefinitions.append(gameDefinition)
        
        shipSet = ShipSet(name: "Lots of tiny ships",
                              description: "15 x 1",
                              uuid: UUID())
        shipSet.addShips(ships: [1: 15])
        shipSets.append(shipSet)
        
        gameDefinition = GameDefinition(name: "Lots of tiny ships",
                                        description: "10 x 10 with 15 tiny ships",
                                        rows: 10,
                                        columns: 10,
                                        shipSetUUID: shipSet.uuid)
        gameDefinitions.append(gameDefinition)
        */
    }
    
    func getShipSetIndex(forShipSetUUID shipSetUUID: UUID) -> Int? {
        for (index, shipSet) in shipSets.enumerated() {
            if shipSet.uuid == shipSetUUID {
                return index
            }
        }
        
        return nil
    }
    
    func isThisShipSetUsed(uuid: UUID) -> Int? {
        for (index, element) in gameDefinitions.enumerated() {
          if element.shipSetUUID == uuid {
              return index
          }
        }
        
        return nil
    }
    
    func loadGameDefinitions() {
        if let gameDefinitions = managerStorege.loadGameDefinitions() {
            self.gameDefinitions = gameDefinitions
        }
    }
    
    func loadSettings() {
        settings = managerStorege.loadSettings()
        if settings == nil {
            settings = Settings()
        }
        
        settings.setNilValues()
    }
    
    func loadShipSets() {
        if let shipSets = managerStorege.loadShipSets() {
            self.shipSets = shipSets
        }
    }
    
    func saveGameDefinitions() {
        managerStorege.save(gameDefinitions: gameDefinitions)
    }
    
    func saveSettings() {
        managerStorege.save(settings: settings)
    }
    
    func saveShipSets() {
        managerStorege.save(shipSets: shipSets)
    }
}
