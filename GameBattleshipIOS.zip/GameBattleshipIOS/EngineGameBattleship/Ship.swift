//
//  Ship.swift
//  GameBattleshipTerminal
//
//  Created by Piotr Fulmański on 2020.03.02.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class Ship: Codable {
    private let size: Int
    private var readyLevel: Int
    var position: [Position]
    
    struct Position: Codable {
        var row: Int
        var column: Int
        var status: Status
        
        init(row: Int, column: Int, status: Status) {
            self.row = row
            self.column = column
            self.status = status
        }
    }
    
    var isDestroyed: Bool {
        return readyLevel == 0 ? true : false
    }
    
    enum Direction {
        case up, down, left, right
    }
    
    enum Status: Int {
        case ready=1, damaged=2, destroyed=3
    }
    
    init(size: Int,
         position: [Position]) {
        self.size = size
        self.position = position
        self.readyLevel = size
    }
    
    func hitAt(row: Int, col: Int) {
        for (index, coordinate) in position.enumerated() {
            if coordinate.row == row &&
                coordinate.column == col {
                position[index].status = Status.damaged
                readyLevel -= 1
                break
            }
        }
    }
    
    func isLocatedAt(row: Int, col: Int) -> Bool {
        for coordinate in position {
            if coordinate.row == row &&
                coordinate.column == col {
                return true
            }
        }
        
        return false
    }
    
}

extension Ship.Status: Codable {
    enum CodingKeys: CodingKey {
        case rawValue
    }
    
    enum CodingError: Error {
        case unknownValue
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let rawValue = try container.decode(Int.self, forKey: .rawValue)
        switch rawValue {
        case 1:
            self = .ready
        case 2:
            self = .damaged
        case 3:
            self = .destroyed
        default:
            throw CodingError.unknownValue
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .ready:
            try container.encode(1, forKey: .rawValue)
        case .damaged:
            try container.encode(2, forKey: .rawValue)
        case .destroyed:
            try container.encode(3, forKey: .rawValue)
        }
    }
}
