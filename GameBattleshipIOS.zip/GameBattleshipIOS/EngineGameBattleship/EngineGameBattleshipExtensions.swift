//
//  EngineGameBattleshipExtensions.swift
//  GameBattleshipTerminal
//
//  Created by Piotr Fulmański on 2020.03.02.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

extension String {
    func leftPadding(toLength: Int, withPad: String = " ") -> String {
        guard toLength > self.count else {return self}
        
        let padding = String(repeating: withPad, count: toLength - self.count)
        
        return padding + self
    }
}
