//
//  Ships.swift
//  GameBattleshipTerminal
//
//  Created by Piotr Fulmański on 2020.03.09.
//  Copyright © 2020 Piotr Fulmański. All rights reserved.
//

import Foundation

class Ships: Codable {
    var ships = [String: Ship]()
    var shipsAtCommand: Int {
        var shipsNumber = ships.count
        
        for (_, ship) in ships {
            if ship.isDestroyed {
                shipsNumber -= 1
            }
        }
        
        return shipsNumber
    }
}
